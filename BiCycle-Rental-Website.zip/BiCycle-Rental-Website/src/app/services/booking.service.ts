import { Injectable } from '@angular/core';
import { bookings } from '../utilities/booking';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, Observable, retry, throwError } from 'rxjs';
import { Constant } from '../utilities/constants';

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  constructor(private httpClient: HttpClient) { }
  

  getAllBookings(): Observable<bookings[]> {
    return this.httpClient
      .get<bookings[]>(Constant.getAllBookings.toString())
      .pipe(retry(1), catchError(this.handleError));
  }
  getBookingsByCycleId(id:number): Observable<bookings[]> {
    return this.httpClient
      .get<bookings[]>(`${Constant.getBookingByCycleId}${id}`)
      .pipe(retry(1), catchError(this.handleError));
  }
  
  addBookingDetail(booking:bookings): Observable<any> {
    const headers = { 'content-type': 'application/json'}  
    const body=JSON.stringify(booking);
    console.log(body)
    return this.httpClient.post(Constant.addABookingDetail.toString(),body,{'headers':headers});
  }
  getBookingByUserId(userId:number)
  {
    return this.httpClient
    .get<bookings[]>(`${Constant.getAllBookingByUserId}${userId}`)
    .pipe(retry(1), catchError(this.handleError));
  }
  changeReturnStauts(id:number)
  {

  }
  handleError(er: any) {
    return throwError(() => {
      console.log(er);
    });
  }
}
