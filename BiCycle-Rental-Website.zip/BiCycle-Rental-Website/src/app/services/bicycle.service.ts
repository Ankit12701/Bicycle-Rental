import { Injectable } from '@angular/core';
// import { Observable,of } from 'rxjs';
import { bicycle } from '../utilities/bicycle';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Constant } from '../utilities/constants';
import { catchError, Observable, retry, throwError } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class BicycleService {

  constructor(private httpClient: HttpClient) { }

  getAllBicycles(): Observable<bicycle[]> {
    return this.httpClient
      .get<bicycle[]>(Constant.getEndpoint.toString())
      .pipe(retry(1), catchError(this.handleError));
  }
  getSpecificBicyclels(id:number): Observable<bicycle> {
    // console.log(`${Constant.getSpecificData}${id}`);
    return this.httpClient
      .get<bicycle>(`${Constant.getSpecificData}${id}`)
      .pipe(retry(1), catchError(this.handleError));
  }
  addBicycle(biCycle:bicycle): Observable<any> {
    const headers = { 'content-type': 'application/json'}  
    const body=JSON.stringify(biCycle);
    console.log(body)
    return this.httpClient.post(Constant.postBiCycles.toString(),body,{'headers':headers});
  }
  deleteBicycle(id:number):Observable<number>{
    return this.httpClient
    .delete<number>(`${Constant.deleteBicycle}${id}`)
    .pipe(retry(1), catchError(this.handleError));
  }
  upadteBicycleDetails(biCycle:bicycle)
  {
    const headers = { 'content-type': 'application/json'}  
    const body=JSON.stringify(biCycle);
    console.log(body)
    return this.httpClient.put(Constant.updateBicycle.toString(),body,{'headers':headers});
  }
  handleError(er: any) {
    return throwError(() => {
      console.log(er);
    });
  }
}
