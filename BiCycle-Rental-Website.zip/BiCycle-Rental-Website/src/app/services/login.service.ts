import { Injectable } from '@angular/core';
import { login } from '../utilities/login';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, Observable, retry, throwError } from 'rxjs';
import { Constant } from '../utilities/constants';
@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private httpClient: HttpClient) { }

   validateLogin(userLogin:login):Observable<any>{
    const headers = { 'content-type': 'application/json'}  
    const body=JSON.stringify(userLogin);
    console.log(body)
    return this.httpClient.post(Constant.authenticateLogin.toString(),body,{'headers':headers});
   }
   validateAdminLogin(adminLogin:login):Observable<any>{
    const headers = { 'content-type': 'application/json'}  
    const body=JSON.stringify(adminLogin);
    console.log(body)
    return this.httpClient.post(Constant.validateAdminLogin.toString(),body,{'headers':headers});
   }
}
