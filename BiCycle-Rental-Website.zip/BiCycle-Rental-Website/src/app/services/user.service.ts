import { Injectable } from '@angular/core';

import { User } from '../utilities/user';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, Observable, retry, throwError } from 'rxjs';
import { Constant } from '../utilities/constants';
@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpClient: HttpClient) { }


  addUser(user:User): Observable<any> {
    const headers = { 'content-type': 'application/json'}  
    const body=JSON.stringify(user);
    console.log(body)
    return this.httpClient.post(Constant.postUser.toString(),body,{'headers':headers});
  }
  getAllUsers(): Observable<User[]> {
    return this.httpClient
      .get<User[]>(Constant.getUsers.toString())
      .pipe(retry(1), catchError(this.handleError));
  }
  getAuserDeatil(name:string ,password:string):Observable<User>{
    return this.httpClient
      .get<User>(`${Constant.getAUserDetail}${name},${password}`)
      .pipe(retry(1), catchError(this.handleError));
  }
  handleError(er: any) {
    return throwError(() => {
      console.log(er);
    });
  }
}
