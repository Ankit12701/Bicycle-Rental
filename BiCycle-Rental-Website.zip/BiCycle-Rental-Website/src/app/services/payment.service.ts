import { Injectable } from '@angular/core';
import { transaction } from '../utilities/transaction';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, Observable, retry, throwError } from 'rxjs';
import { Constant } from '../utilities/constants';
@Injectable({
  providedIn: 'root'
})
export class PaymentService {

  constructor(private httpClient: HttpClient) { }

  getAllTransaction(): Observable<transaction[]> {
    return this.httpClient
      .get<transaction[]>(Constant.getAllTransaction.toString())
      .pipe(retry(1), catchError(this.handleError));
  }
  addTransaction(transaction:transaction): Observable<any> {
    const headers = { 'content-type': 'application/json'}  
    const body=JSON.stringify(transaction);
    console.log(body)
    return this.httpClient.post(Constant.addTransaction.toString(),body,{'headers':headers});
  }
  getTransactionByuserId(userId:number): Observable<transaction[]>
  {
    return this.httpClient
    .get<transaction[]>(`${Constant.getAllTransactionByUserId}${userId}`)
    .pipe(retry(1), catchError(this.handleError));
  }
  handleError(er: any) {
    return throwError(() => {
      console.log(er);
    });
  }
}
