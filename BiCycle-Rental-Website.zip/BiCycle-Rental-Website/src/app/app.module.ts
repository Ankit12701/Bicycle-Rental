import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BicycleCardComponent } from './components/bicycle-card/bicycle-card.component';
import { LoginComponent } from './components/login/login.component';
import { SignupComponent } from './components/signup/signup.component';
import { FormsModule } from '@angular/forms';
import { AddBicycleComponent } from './components/add-bicycle/add-bicycle.component';
import { BookingComponent } from './components/booking/booking.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { UserGridComponent } from './components/user-grid/user-grid.component';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { AdminListGroupComponent } from './components/admin-list-group/admin-list-group.component';
import { BookingGridComponent } from './components/booking-grid/booking-grid.component';

import { AdminLoginComponent } from './components/admin-login/admin-login.component';

import { BicycleListComponent } from './components/bicycle-list/bicycle-list.component';
import { EditBicycleComponent } from './components/edit-bicycle/edit-bicycle.component';
import { PaymentGridComponent } from './components/payment-grid/payment-grid.component';
import { AdminNavbarComponent } from './components/admin-navbar/admin-navbar.component';
import { UserNavbarComponent } from './components/user-navbar/user-navbar.component';
import { UserTransactionGridComponent } from './components/user-transaction-grid/user-transaction-grid.component';
import { UserBookingGridComponent } from './components/user-booking-grid/user-booking-grid.component';
@NgModule({
  declarations: [
    AppComponent,
    BicycleCardComponent,
    LoginComponent,
    SignupComponent,
    AddBicycleComponent,
    BookingComponent,
    UserGridComponent,
    AdminListGroupComponent,
    BookingGridComponent,
    AdminLoginComponent,
    BicycleListComponent,
    EditBicycleComponent,
    PaymentGridComponent,
    AdminNavbarComponent,
    UserNavbarComponent,
    UserTransactionGridComponent,
    UserBookingGridComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    BrowserAnimationsModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatInputModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
