import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BicycleCardComponent } from './components/bicycle-card/bicycle-card.component';
import { SignupComponent } from './components/signup/signup.component';
import { AddBicycleComponent } from './components/add-bicycle/add-bicycle.component';
import { LoginComponent } from './components/login/login.component';
import { BookingComponent } from './components/booking/booking.component';
import { UserGridComponent } from './components/user-grid/user-grid.component';
import { AdminListGroupComponent } from './components/admin-list-group/admin-list-group.component';
import { BookingGridComponent } from './components/booking-grid/booking-grid.component';

import { AdminLoginComponent } from './components/admin-login/admin-login.component';

import { BicycleListComponent } from './components/bicycle-list/bicycle-list.component';
import { EditBicycleComponent } from './components/edit-bicycle/edit-bicycle.component';
import { PaymentGridComponent } from './components/payment-grid/payment-grid.component';
import { UserBookingGridComponent } from './components/user-booking-grid/user-booking-grid.component';
import { UserTransactionGridComponent } from './components/user-transaction-grid/user-transaction-grid.component';
const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'bicycle', component: BicycleCardComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'add-bicycle', component:AddBicycleComponent},
  { path: 'login', component:LoginComponent},
  { path: 'addBooking/:id', component:BookingComponent},
  { path: 'allUsers', component:UserGridComponent},
  { path: 'admin', component:AdminListGroupComponent},
  { path: 'allBookings', component:BookingGridComponent},

  { path: 'adminLogin', component:AdminLoginComponent},

  { path: 'bicycle-list', component:BicycleListComponent},
  { path: 'edit/:id', component:EditBicycleComponent},
  { path: 'payment-grid', component:PaymentGridComponent},
  { path:'user-booking', component:UserBookingGridComponent},
  { path:'user-transaction', component:UserTransactionGridComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
