export interface bicycle{
    id:string;
    brandName:string;
    brandId:number;
    color:string;
    description:string;
    imageUrl:string;
    pricePerDay:number;
    quantity:number;
};