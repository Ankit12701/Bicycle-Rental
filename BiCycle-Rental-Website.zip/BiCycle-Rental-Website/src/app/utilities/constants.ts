import { environment } from 'src/environments/environment';

export module Constant {
  const baseUrl: String = environment.baseURL;
  export const getEndpoint: String = `${baseUrl}api/Bicycle`;
//   export const editEndPoint:String =`${baseUrl}/movies/`;
  export const getSpecificData:String=`${baseUrl}api/Bicycle/`;
  // export const getUsers:string=`${baseUrl}/user`;
 // export const postUser:string=`${baseUrl}/user`;
 export const getUsers:string=`${baseUrl}api/User `;
 export const postUser:string =`${baseUrl}api/User`;
  export const postBiCycles:string=`${baseUrl}api/Bicycle`;
  export const postBooking:string=`${baseUrl}booking`; 
  export const getAllBookings:string=`${baseUrl}api/Booking`;
  export const authenticateLogin:string =`${baseUrl}api/Login`;
  export const getBookingByCycleId:string =`${baseUrl}api/Booking/`;
  export const addABookingDetail:string=`${baseUrl}api/Booking`;
  export const  getAUserDetail:string=`${baseUrl}api/User/`;
  export const getAllTransaction:string=`${baseUrl}api/Transaction`;
  export const addTransaction:string=`${baseUrl}api/Transaction`;
export const deleteBicycle:string=`${baseUrl}api/Bicycle?id=`;
export const updateBicycle:string=`${baseUrl}api/Bicycle`;

export const validateAdminLogin:string=`${baseUrl}adminLogin`;
export const getAllBookingByUserId:string=`${baseUrl}api/Booking/getBookingsById?userId=`;
export const getAllTransactionByUserId=`${baseUrl}api/Transaction/getTransactionsByUserId?userId=`;
}
