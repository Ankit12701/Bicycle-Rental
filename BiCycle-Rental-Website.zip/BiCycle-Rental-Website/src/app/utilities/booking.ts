export interface bookings{
    
        userName:string,
        userId: number,
        email: string,
        bookingDateFrom: string,
        bookingDateTo: string,
        governmentId: string,
        amount: number,
        returnStatus:number,
        bookingId:string,
        quantity:number,
        cycleId:number
}