export interface transaction{
    transactionId:number,
    userName:string,
    userid:number,
   
    bookingDateFrom:string,
    bookingDateTo:string,
    amount:number
}