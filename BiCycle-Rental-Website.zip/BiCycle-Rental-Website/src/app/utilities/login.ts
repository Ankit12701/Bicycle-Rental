export interface login{
    name:string,
    password:string
}