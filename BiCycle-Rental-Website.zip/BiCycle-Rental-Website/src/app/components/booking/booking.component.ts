import { Component, OnInit } from '@angular/core';
import { bookings } from 'src/app/utilities/booking';
import { BookingService } from 'src/app/services/booking.service';
import { GuardsCheckEnd } from '@angular/router';
import { ActivatedRoute, UrlSerializer } from '@angular/router';
import { Router } from '@angular/router';
import { BicycleService } from 'src/app/services/bicycle.service';
import { User } from 'src/app/utilities/user';
import { PaymentService } from 'src/app/services/payment.service';
import Swal from 'sweetalert2'
import { transaction } from 'src/app/utilities/transaction';
import { bicycle } from 'src/app/utilities/bicycle';
@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {

  constructor(private bookingService:BookingService, private bicycleServices:BicycleService,private route: ActivatedRoute,private router:Router, private paymentService:PaymentService) { }
  res=0;
  user1=JSON.parse(localStorage.getItem('login_user') || '[]');
  ngOnInit(): void {
   let id:number= Number(this.route.snapshot.paramMap.get('id'));
   this.bicycleServices.getSpecificBicyclels(id).subscribe((data) => {
    this.bicyleImage=data.imageUrl;
   });
  
  }
  
  
  userName:string=this.user1.name;
  userId: number=this.user1.id;
  email: string=this.user1.email;
  bookingDateFrom: string="02/07/2018";
  bookingDateTo: string="02/07/2019"
  governmentId: string=""
  returnStatus: number=0
  amount: number=0
  bookingId:string="12";
  counter=0;
  bookings:any;
  bicycleDetails:bicycle[]=[];
  bicyleImage:string="";
 
  increaseValue(){
    this.counter=this.counter+1;
  }
  decreaseValue(){
    this.counter=this.counter-1;
  }
  submitHandler(userName:string,email:string,bookingDateFrom:string,bookingDateTo:string,governmentId:string){
   
    let booking:bookings= {
      "userName": "userName 1",
      "userId": 82,
      "email": "email 1",
      "bookingDateFrom": "bookingDateFrom 1",
      "bookingDateTo": "bookingDateTo 1",
      "governmentId": "97",
      "returnStatus": 0,
      "amount": 39,
      "bookingId": "1",
      "quantity":0,
      "cycleId":0,
   
     }

     let transaction:transaction={
      "transactionId":1,
      "userName":"",
      "userid":1,
     
      "bookingDateFrom":"",
      "bookingDateTo":"",
      "amount":0
     }
     if(governmentId=="")
     {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Please fill all the details',
       
      })
     }
     else
     {
     booking.userId=this.user1.id;
     booking.userName=userName;
     booking.email=email;
     booking.bookingDateFrom=bookingDateFrom;
     booking.bookingDateTo=bookingDateTo;
     booking.governmentId=governmentId;
     const bookingFromDate=new Date(bookingDateFrom);
     const bookingToDate=new Date(bookingDateTo);
     const diffInHours:any=((<any>bookingToDate  - <any>bookingFromDate ) / (3.6e+6) );
     console.log("difference in hours",diffInHours);
     booking.amount=diffInHours;
     booking.bookingId="1000";
     booking.quantity=this.counter;
     booking.cycleId=Number(this.route.snapshot.paramMap.get('id'));
     
     this.bicycleServices.getSpecificBicyclels(booking.cycleId).subscribe(bicycleDetail=>{
      
      this.bicycleDetails[0]=bicycleDetail;
      this.bicyleImage=this.bicycleDetails[0].imageUrl;
      console.log(this.bicycleDetails);
      console.log(this.bicycleDetails[0]);
      booking.amount=diffInHours*this.bicycleDetails[0].pricePerDay;
      console.log("the booking amount is",booking.amount);
     
      this.bookingService.getBookingsByCycleId(booking.cycleId).subscribe((data) => {
    
    
        this.bookings=data;
        console.log(this.bookings);
        console.log("after printing the bookins in submit handeler");
        if(this.bookings==null && booking.quantity<=this.bicycleDetails[0].quantity)
        {
        console.log("pno previous booking exists i the db so add ot in the db");
        

        Swal.fire({
        
          text: 'Pay through the QR Code',
          imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d0/QR_code_for_mobile_English_Wikipedia.svg/1200px-QR_code_for_mobile_English_Wikipedia.svg.png',
          imageWidth: 400,
          imageHeight: 200,
          imageAlt: 'Custom image',
          timer: 5000
        })
        this.bookingService.addBookingDetail(booking).subscribe((booking)=>{
         booking=booking;
        
          transaction.transactionId=Math.floor(Math.random() * (999999 - 111111 + 1)) + 111111;
          transaction.userid=this.user1.id;
          transaction.userName=this.user1.name;
          transaction.bookingDateFrom=bookingDateFrom;
          transaction.bookingDateTo=bookingDateTo;
          transaction.amount=booking.amount;
          this.paymentService.addTransaction(transaction).subscribe(transaction=>transaction=transaction);
          this.router.navigate(['/','bicycle']);
        });
        
        }
        else
        {
        this.checkAvailability(this.bookings,bookingDateFrom,bookingDateTo,booking,this.bicycleDetails[0],booking.amount);
       
      }
      });
     
    });
  
  }
    
  }
  checkAvailability(bookings:bookings[],bookingDateFrom:string,bookingDateTo:string,booking:bookings,bicycle:bicycle,amount:number){
    let transaction:transaction={
      "transactionId":1,
      "userName":"",
      "userid":1,
     
      "bookingDateFrom":"",
      "bookingDateTo":"",
      "amount":0
     }
     
    let bookings1=[];
    bookings1=bookings;
    console.log(bookings1);
    console.log("inside check availability function");
    let startTime = new Date(bookingDateFrom);
    let endTime = new Date(bookingDateTo)
    let min:number=1000;
   
      for(let i=0;i<bookings1.length;i++){
        console.log("inside bookings");
      let bookedStartTime=new Date(bookings1[i].bookingDateFrom);
      let bookedEndTime= new Date(bookings1[i].bookingDateTo);
      if((startTime > bookedStartTime && startTime < bookedEndTime) || (endTime > bookedStartTime && endTime < bookedEndTime) || (startTime <= bookedStartTime && endTime >= bookedEndTime)) {
            if(bicycle.quantity-bookings1[i].quantity<min)
            min=bicycle.quantity-bookings1[i].quantity;
      }
      

      console.log("minimum number of bicycle that can be rent",min);
    
    }
    console.log(min);
    if(min==1000 && booking.quantity<=bicycle.quantity)
    {
    console.log("no booking exists in the db for the requested time period so adding it to the db");
  

    Swal.fire({
      text: 'Pay through the QR Code',
      imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d0/QR_code_for_mobile_English_Wikipedia.svg/1200px-QR_code_for_mobile_English_Wikipedia.svg.png',
      imageWidth: 400,
      imageHeight: 200,
      imageAlt: 'Custom image',
      timer: 20000
    })
    this.bookingService.addBookingDetail(booking).subscribe((booking)=>{
      booking=booking;
   
      transaction.transactionId=Math.floor(Math.random() * (999999 - 111111 + 1)) + 111111;
      transaction.userid=this.user1.id;
      transaction.userName=this.user1.name;
      transaction.bookingDateFrom=bookingDateFrom;
      transaction.bookingDateTo=bookingDateTo;
      transaction.amount=amount;
      this.paymentService.addTransaction(transaction).subscribe(transaction=> transaction=transaction);
      this.router.navigate(['/','bicycle']);
    });
    
    }
    else if(min!=1000 && booking.quantity<=min)
    {
    console.log("entry exists int he db for the time period and quantity asked is available");
    
    Swal.fire({
      text: 'Pay through the QR Code',
      imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d0/QR_code_for_mobile_English_Wikipedia.svg/1200px-QR_code_for_mobile_English_Wikipedia.svg.png',
      imageWidth: 400,
      imageHeight: 200,
      imageAlt: 'Custom image',
      timer: 5000
    })
    this.bookingService.addBookingDetail(booking).subscribe((booking)=>{
      booking=booking;
   
      transaction.transactionId=Math.floor(Math.random() * (999999 - 111111 + 1)) + 111111;
      transaction.userid=this.user1.id;
      transaction.userName=this.user1.name;
      transaction.bookingDateFrom=bookingDateFrom;
      transaction.bookingDateTo=bookingDateTo;
      transaction.amount=amount;
      this.paymentService.addTransaction(transaction).subscribe(transaction=>transaction=transaction);
      this.router.navigate(['/','bicycle']);
    });
    }else
    {
     console.log("the requested number of bike for the time period is not available"); 
    }

 
}
}

