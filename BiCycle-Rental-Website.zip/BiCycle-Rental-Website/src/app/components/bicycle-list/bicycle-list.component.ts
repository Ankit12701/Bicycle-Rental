import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { bicycle } from 'src/app/utilities/bicycle';
import { BicycleService } from 'src/app/services/bicycle.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-bicycle-list',
  templateUrl: './bicycle-list.component.html',
  styleUrls: ['./bicycle-list.component.css']
})
export class BicycleListComponent implements OnInit {



  ngOnInit(): void {
  }

  displayedColumns: string[] = ['id','brandId','brandName','color','description','imageUrl','quantity','pricePerDay','edit','delete'];
  dataSource!: MatTableDataSource<bicycle>;
  cycles: any;
 
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private bicycleService: BicycleService,private router:Router) {
    this.bicycleService.getAllBicycles().subscribe((data) => {
      console.log(data);
      this.cycles = data;
      // Assign the data to the data source for the table to render
      this.dataSource = new MatTableDataSource(this.cycles);

      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
    // Create 100 users
    // const users = Array.from({ length: 100 }, (_, k) => createNewUser(k + 1));
    // console.log(this.posts);
    // console.log('users', users);
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  delete(id:number)
  {
    console.log(id);
    this.bicycleService.deleteBicycle(id).subscribe((id)=>id=id);
    this.router.navigate(['/','bicycle-list']);
  }
  edit(id:number)
  {

  }

}
