import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { BookingService } from 'src/app/services/booking.service';
import { bookings } from 'src/app/utilities/booking';


@Component({
  selector: 'app-booking-grid',
  templateUrl: './booking-grid.component.html',
  styleUrls: ['./booking-grid.component.css']
})
export class BookingGridComponent implements OnInit {



  ngOnInit(): void {
  }
  displayedColumns: string[] = ['bookingId','userName','userId','email','bookingDateFrom','bookingDateTo','amount','governmentId','quantity'];
  dataSource!: MatTableDataSource<bookings>;
  bookings: any;
 
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private bookingService: BookingService) {
 
    this.bookingService.getAllBookings().subscribe((data) => {
      console.log(data);
      this.bookings = data;
      // Assign the data to the data source for the table to render
      this.dataSource = new MatTableDataSource(this.bookings);

      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
    // Create 100 users
    // const users = Array.from({ length: 100 }, (_, k) => createNewUser(k + 1));
    // console.log(this.posts);
    // console.log('users', users);
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  
  upadateDetails()
  {

  }
}
