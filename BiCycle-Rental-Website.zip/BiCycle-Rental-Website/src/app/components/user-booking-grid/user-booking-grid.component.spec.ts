import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserBookingGridComponent } from './user-booking-grid.component';

describe('UserBookingGridComponent', () => {
  let component: UserBookingGridComponent;
  let fixture: ComponentFixture<UserBookingGridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserBookingGridComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserBookingGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
