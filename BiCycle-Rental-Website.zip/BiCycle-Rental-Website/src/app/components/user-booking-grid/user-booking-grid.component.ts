import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { BookingService } from 'src/app/services/booking.service';
import { bookings } from 'src/app/utilities/booking';


@Component({
  selector: 'app-user-booking-grid',
  templateUrl: './user-booking-grid.component.html',
  styleUrls: ['./user-booking-grid.component.css']
})
export class UserBookingGridComponent implements OnInit {


  ngOnInit(): void {
  }
  displayedColumns: string[] = ['bookingId','userName','userId','email','bookingDateFrom','bookingDateTo','amount','governmentId','quantity'];
  dataSource!: MatTableDataSource<bookings>;
  bookings: any;
 
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private bookingService: BookingService) {
    let user1=JSON.parse(localStorage.getItem('login_user') || '[]');
    this.bookingService.getBookingByUserId(user1.id).subscribe((data) => {
      console.log(data);
      this.bookings = data;
      // Assign the data to the data source for the table to render
      this.dataSource = new MatTableDataSource(this.bookings);

      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
   
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  

}
