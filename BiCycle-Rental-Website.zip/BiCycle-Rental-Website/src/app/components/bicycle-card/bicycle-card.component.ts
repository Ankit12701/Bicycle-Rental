import { Component, OnInit } from '@angular/core';
import { BicycleService } from 'src/app/services/bicycle.service';
import { bicycle } from 'src/app/utilities/bicycle';


@Component({
  selector: 'app-bicycle-card',
  templateUrl: './bicycle-card.component.html',
  styleUrls: ['./bicycle-card.component.css']
})
export class BicycleCardComponent implements OnInit {

  constructor(private biCycleService:BicycleService) { }
  biCycles:bicycle[]=[];
  ngOnInit(): void {
       this.getAllBicycles();
  }
  // getAllBicycles(): void {
  //   this.biCycleService.getAllBicycles()
  //   .subscribe(biCycles => this.biCycles = biCycles);
  // }
  getAllBicycles(): void {
    this.biCycleService.getAllBicycles()
    .subscribe(biCycles => {
      this.biCycles = biCycles
    });
   

}
}
