import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BicycleCardComponent } from './bicycle-card.component';

describe('BicycleCardComponent', () => {
  let component: BicycleCardComponent;
  let fixture: ComponentFixture<BicycleCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BicycleCardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BicycleCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
