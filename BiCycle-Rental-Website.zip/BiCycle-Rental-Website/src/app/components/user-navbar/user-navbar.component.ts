import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-navbar',
  templateUrl: './user-navbar.component.html',
  styleUrls: ['./user-navbar.component.css']
})
export class UserNavbarComponent implements OnInit {

  constructor(private router:Router) { }
 
  name:string="";
  ngOnInit(): void {
    let user1:any=JSON.parse(localStorage.getItem('login_user') || '[]');
    this.name=user1.name;
  }

  logout()
  {

    localStorage.removeItem("login_user");
    this.router.navigate(['/','login']);
  }

}
