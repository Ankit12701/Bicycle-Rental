import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-list-group',
  templateUrl: './admin-list-group.component.html',
  styleUrls: ['./admin-list-group.component.css']
})
export class AdminListGroupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
