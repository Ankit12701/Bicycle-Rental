import { Component, OnInit } from '@angular/core';
import { bicycle } from 'src/app/utilities/bicycle';
import { BicycleService } from 'src/app/services/bicycle.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-add-bicycle',
  templateUrl: './add-bicycle.component.html',
  styleUrls: ['./add-bicycle.component.css']
})
export class AddBicycleComponent implements OnInit {

  constructor(private biCycleServives:BicycleService,private router:Router) { }
  id:string=""
  brandName:string=""
  brandId:number=0;
  color:string=""
  Description:string=""
  imageUrl:string=""
  pricePerDay:number=0;
  quantity:number=0;
  ngOnInit(): void {
  }
  
  submitHandler(brandName:string,brandId:number,color:string,Description:string,imageUrl:string,pricePerDay:number,quantity:number){
    let bicycle:bicycle={
      "id":"6",
      "brandName":"Hero",
      "brandId":101,
      "color":"Black",
      "description":"Black Bicycle",
      "imageUrl":"https://i.pinimg.com/736x/9c/b3/bf/9cb3bf734262bd523bafd5b9d7c53da0--cannondale-bikes-cycling-bikes.jpg",
      "pricePerDay":1,
      "quantity":0
  }
      bicycle.id="122";
      bicycle.brandName=brandName;
      bicycle.brandId=brandId;
      bicycle.color=color;
      bicycle.description=Description;
      bicycle.imageUrl=imageUrl;
      bicycle.pricePerDay=pricePerDay;
      bicycle.quantity=quantity;
      this.biCycleServives.addBicycle(bicycle).subscribe(addBicycle => addBicycle = addBicycle);

      Swal.fire({
    
        icon: 'success',
        title: 'Details updated successfuly',
        showConfirmButton: false,
        timer: 1500
      })
       this.router.navigate(['/','admin']);
  }
}
