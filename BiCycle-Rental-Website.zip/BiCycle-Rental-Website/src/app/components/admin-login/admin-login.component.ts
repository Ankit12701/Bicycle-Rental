import { Component, OnInit } from '@angular/core';
import { login } from 'src/app/utilities/login';
import { LoginService } from 'src/app/services/login.service';
import { ActivatedRoute, UrlSerializer } from '@angular/router';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { User } from 'src/app/utilities/user';
@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {

  constructor(private loginService:LoginService,private userService:UserService,private route: ActivatedRoute,private router:Router) { }

  ngOnInit(): void {
  }
  name:string="";
  password:string="";
  result:any;
  

  submitHandler(name:string,pasword:string)
  {
    console.log(name);
    console.log(pasword);
    let temp:login={name:"",password:""}
    temp.name=name;
    temp.password=pasword;
    this.loginService.validateAdminLogin(temp).subscribe((x:any)=>{
      this.result=x;
      console.log("The value of var is",this.result);

      if(this.result==200)
      {
      
   
      this.getDetails(name,pasword);
      this.router.navigate(['/','admin']);
      }

      
    });
   
 
  }
  getDetails(name:string,password:string)
  {
    this.userService.getAuserDeatil(name,password).subscribe((user:User)=>
    {
       console.log(user);
       localStorage.setItem("login_user",JSON.stringify(user));
    });
  }
  
}
