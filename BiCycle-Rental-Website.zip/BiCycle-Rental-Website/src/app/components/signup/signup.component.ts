import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { User } from 'src/app/utilities/user';
import { ActivatedRoute, UrlSerializer } from '@angular/router';
import { Router } from '@angular/router';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private userService:UserService,private route: ActivatedRoute,
    private router:Router) { }
  name:string=""
  email:string=""
  password:string=""
  role: string=""
  phonenumber:string=""
  userId: number=0
  age:number=10;
  ngOnInit(): void {
  }
  submitHandler(userName:string,email:string,password:string,phoneNumber:string,age:number){
    let user:User={
      "name": "Ankit",
      "email": "abc@def.com",
      "password": "abcde",
      "role": "user",
      "phonenumber": "1234567899",
       "id":999,
       "age":18
     };
     
     user.name=userName;
     user.email=email;
     user.password=password;
     user.phonenumber=phoneNumber;
     user.role="user";
     user.age=age;
    
     this.userService.addUser(user).subscribe(user => user = user);
     this.router.navigate(['/','bicycle']);
  }
}
