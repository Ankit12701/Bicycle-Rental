import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserTransactionGridComponent } from './user-transaction-grid.component';

describe('UserTransactionGridComponent', () => {
  let component: UserTransactionGridComponent;
  let fixture: ComponentFixture<UserTransactionGridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserTransactionGridComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserTransactionGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
