import { Component, OnInit, ViewChild } from '@angular/core';
import { PaymentService } from 'src/app/services/payment.service';
import { transaction } from 'src/app/utilities/transaction';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-user-transaction-grid',
  templateUrl: './user-transaction-grid.component.html',
  styleUrls: ['./user-transaction-grid.component.css']
})
export class UserTransactionGridComponent implements OnInit {

  ngOnInit(): void {
  }
  displayedColumns: string[] = ['transactionId','userName','userId','bookingDateFrom','bookingDateTo','amount'];
  dataSource!: MatTableDataSource<transaction>;
  payments: any;
 
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  constructor(private paymentServie:PaymentService) 
  {
    let user1=JSON.parse(localStorage.getItem('login_user') || '[]');
    this.paymentServie.getTransactionByuserId(user1.id).subscribe((data)=>{
      console.log(data);
      this.payments=data;
      this.dataSource = new MatTableDataSource(this.payments);

      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    })
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  

}
