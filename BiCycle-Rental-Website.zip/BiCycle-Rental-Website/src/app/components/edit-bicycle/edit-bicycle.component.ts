import { Component, OnInit } from '@angular/core';
import { bicycle } from 'src/app/utilities/bicycle';
import { BicycleService } from 'src/app/services/bicycle.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Route } from '@angular/router';
import Swal from 'sweetalert2'
@Component({
  selector: 'app-edit-bicycle',
  templateUrl: './edit-bicycle.component.html',
  styleUrls: ['./edit-bicycle.component.css']
})
export class EditBicycleComponent implements OnInit {
  id:number=0;
  //id:string=""
  brandName:string=""
  brandId:number=0;
  color:string=""
  description:string="abc"
  imageUrl:string=""
  pricePerDay:number=0;
  quantity:number=0;

  constructor(private bicycleService: BicycleService,private router:Router,private route: ActivatedRoute,) { }

  ngOnInit(): void {
    this.getABicycleDetail();
  }
  bicycle:bicycle={
    "id":"6",
    "brandName":"Hero",
    "brandId":101,
    "color":"Black",
    "description":"Black Bicycle",
    "imageUrl":"https://i.pinimg.com/736x/9c/b3/bf/9cb3bf734262bd523bafd5b9d7c53da0--cannondale-bikes-cycling-bikes.jpg",
    "pricePerDay":1,
    "quantity":0
}
  getABicycleDetail()
  {
    this.id= Number(this.route.snapshot.paramMap.get('id'));
    this.bicycleService.getSpecificBicyclels(this.id).subscribe((temp)=>{
      this.bicycle=temp;
      this.brandName=this.bicycle.brandName;
      this.description=this.bicycle.description;
      this.color=this.bicycle.color;
      this.imageUrl=this.bicycle.imageUrl;
      this.pricePerDay=this.bicycle.pricePerDay;
      this.quantity=this.bicycle.quantity;
    });
  }
  
  submitHandler(color:string,Description:string,imageUrl:string,pricePerDay:number,quantity:number)
  {
   
    console.log(color);
    console.log(Description);
    console.log(quantity);
    console.log(pricePerDay);
  
     this.bicycle.description=Description;
     this.bicycle.imageUrl=imageUrl;
     this.bicycle.pricePerDay=pricePerDay;
     this.bicycle.quantity=quantity;
     this.bicycle.color=color;
     console.log(this.bicycle);
     this.bicycleService.upadteBicycleDetails(this.bicycle).subscribe((temp)=>{
      console.log(temp);
      console.log(this.bicycle);
     });
     Swal.fire({
    
      icon: 'success',
      title: 'Details updated successfuly',
      showConfirmButton: false,
      timer: 1500
    })
     this.router.navigate(['/','admin']);
     

  }
}

