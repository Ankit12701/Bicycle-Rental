export const environment = {
  production: true,
  baseURL: 'https://localhost:44312/'
};
