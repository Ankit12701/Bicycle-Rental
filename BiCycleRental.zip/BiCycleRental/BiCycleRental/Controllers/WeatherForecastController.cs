﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

using BiCycleRental.Interface;
namespace BiCycleRental.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        //[HttpGet]
        //public IEnumerable<WeatherForecast> Get()
        //{
        //    var rng = new Random();
        //    return Enumerable.Range(1, 5).Select(index => new WeatherForecast
        //    {
        //        Date = DateTime.Now.AddDays(index),
        //        TemperatureC = rng.Next(-20, 55),
        //        Summary = Summaries[rng.Next(Summaries.Length)]
        //    })
        //    .ToArray();
        //}

        [HttpGet]
        public  List<Ifood> GetAll()
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48894\\SQLEXPRESS;Database=orderdetails;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();

                string query = "select * from food";

                SqlCommand cmd = new SqlCommand(query, connection);

                var a = cmd.ExecuteReader();

                if(a.HasRows)
                {
                    List<Ifood> food = new List<Ifood>();

                    Ifood food1 = null;

                    while (a.Read())
                    {
                        food1=new Ifood();
                        food1.id = Convert.ToInt32(a["id"]);
                        food1.name = a["name"].ToString();
                        food1.loction = a["location"].ToString();

                        food.Add(food1);
                    }

                    return food;


                }
                else
                {
                    return null;
                }

            }
            catch (Exception)
            {

                throw;
            }
        }

        [HttpPost]

        public List<Ifood> PostAll(Ifood input)
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48894\\SQLEXPRESS;Database=orderdetails;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();

                string query = "insert into dbo.food (name,location) values('"+ input.name + @"','"+ input.loction + @"')";

                SqlCommand cmd = new SqlCommand(query, connection);

                var a = cmd.ExecuteReader();

                if (a.HasRows)
                {
                    List<Ifood> food = new List<Ifood>();

                    Ifood food1 = null;

                    while (a.Read())
                    {
                        food1 = new Ifood();
                        food1.id = Convert.ToInt32(a["id"]);
                        food1.name = a["name"].ToString();
                        food1.loction = a["location"].ToString();

                        food.Add(food1);
                    }

                    return food;


                }
                else
                {
                    return null;
                }

            }
            catch (Exception)
            {

                throw;
            }
        }

        [HttpDelete("{id}")]
        public List<Ifood> DeleteItem(string id)
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48894\\SQLEXPRESS;Database=orderdetails;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();

                int idInt = int.Parse(id);

                string query = "delete from food where id=" + idInt + "";

                SqlCommand cmd = new SqlCommand(query, connection);

                var a = cmd.ExecuteReader();

                if (a.HasRows)
                {
                    List<Ifood> food = new List<Ifood>();

                    Ifood food1 = null;

                    while (a.Read())
                    {
                        food1 = new Ifood();
                        food1.id = Convert.ToInt32(a["id"]);
                        food1.name = a["name"].ToString();
                        food1.loction = a["location"].ToString();

                        food.Add(food1);
                    }

                    return food;


                }
                else
                {
                    return null;
                }

            }
            catch (Exception)
            {

                throw;
            }
        }
    }

}
    



    //public int postFood()
    //{
    //    SqlConnection connection = new SqlConnection("Server=APINP-ELPT48894\\SQLEXPRESS;Database=orderdetails;Integrated Security=false;User Id=sa;Password=guvi;");

    //    connection.Open();

    //    string query = "insert into food(name,location) values('abc','def')";

    //    SqlCommand cmd = new SqlCommand(query, connection);

    //    var a = cmd.ExecuteReader();

    //    return 0;
    //}

   


