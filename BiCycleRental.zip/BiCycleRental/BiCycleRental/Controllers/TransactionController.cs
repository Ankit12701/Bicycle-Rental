﻿using BiCycleRental.Interface;
using BiCycleRental.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using BiCycleRental.Implementation;

namespace BiCycleRental.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
  
    public class TransactionController : ControllerBase
    {
        private readonly InterfaceTransaction interfaceTransaction;
        private readonly ILogger<TransactionController> _logger;
        public TransactionController(InterfaceTransaction interfaceTransaction, ILogger<TransactionController> logger)
        {
            this.interfaceTransaction = interfaceTransaction;
            _logger = logger;
        }
        [HttpGet]
        public List<transaction> getAllTransaction()
        {
            return this.interfaceTransaction.getAllTransaction();
        }

        [HttpPost]
        public transaction addTransaction(transaction transaction)
        {
            return this.interfaceTransaction.addTransaction(transaction);
        }

        [HttpGet("getTransactionsByUserId")]

        public List<transaction> getAllTransactionByUserId(int userId)
        {
            return this.interfaceTransaction.getAllTransactionByUserId(userId);
       
        }
    }
}
