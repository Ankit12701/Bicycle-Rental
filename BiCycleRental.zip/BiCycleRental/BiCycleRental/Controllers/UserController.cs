﻿using BiCycleRental.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using BiCycleRental.Implementation;
using System.Collections.Generic;
using BiCycleRental.Models;
using Microsoft.Extensions.Logging;
using System.Data.SqlClient;
using System;

namespace BiCycleRental.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        //private readonly ImplmentationUser implementationUser;
        private readonly InterfaceUser interfaceUser;
        private readonly ILogger<UserController> _logger;
        public UserController(ILogger<UserController> logger,InterfaceUser interfaceuser)
        {
            _logger = logger;
            interfaceUser = interfaceuser;
        }

        [HttpGet]
        public List<user> getRequest()
        {
            //List<user> users = new List<user>();
            //users= this.iuser.GetAllUsers();
            //return users;

            return this.interfaceUser.GetAllUsers();
        }

        [HttpPost]
        public List<user> PostAll(user input)
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48894\\SQLEXPRESS;Database=BiCycle;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();

                string query = "insert into dbo.users (name,age,email,password,phoneNumber) values('" + input.name + @"','" + input.age + @"','" + input.email + @"','" + input.password + @"','"+ input.phonenumber + @"')";

                SqlCommand cmd = new SqlCommand(query, connection);

                var a = cmd.ExecuteReader();

                if (a.HasRows)
                {
                    List<user> users = new List<user>();

                    user user = null;

                    while (a.Read())
                    {
                        user = new user();
                        user.id = Convert.ToInt32(a["id"]);
                        user.name = a["name"].ToString();
                        

                        users.Add(user);
                    }

                    return users;


                }
                else
                {
                    return null;
                }

            }
            catch (Exception)
            {

                throw;
            }
        }

        [HttpGet("{name},{password}")]
        public user getAuser(string name,string password)
        {
            return this.interfaceUser.getAuser(name, password);
        }
    }
}
