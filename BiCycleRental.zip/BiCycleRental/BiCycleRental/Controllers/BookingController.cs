﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using BiCycleRental.Models;
using BiCycleRental.Interface;
using Microsoft.Extensions.Logging;

namespace BiCycleRental.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingController : ControllerBase
    {
        private readonly InterfaceBooking interfaceBooking;
        private readonly ILogger<UserController> _logger;
        public BookingController(InterfaceBooking interfaceBooking, ILogger<UserController> logger)
        {
            this.interfaceBooking = interfaceBooking;
            _logger = logger;
        }
        [HttpGet]
        public List<booking> getAllBookings()
        {
            return this.interfaceBooking.getAllBooking();
        }

        [HttpGet("{id}")]

        public List<booking> getSpecificDateRangeBookings(int id)
        {
            return this.interfaceBooking.getSpecificDateRangeBookings(id);    
        }

        [HttpPost]

        public booking addBookingDetails(booking booking)
        {
            return this.interfaceBooking.addBookingDetails(booking);
        }


        [HttpGet("getBookingsById")]

        public List<booking> getAllBookingByUserId(int userId)
        {
            return this.interfaceBooking.getBookingByUserId(userId);
        }
    }
}
