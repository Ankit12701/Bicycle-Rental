﻿using BiCycleRental.Interface;
using BiCycleRental.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading;

namespace BiCycleRental.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BicycleController : Controller
    {
        private readonly InterfaceBicycle interfaceBicycles;
        private readonly ILogger<UserController> _logger;
        public BicycleController(InterfaceBicycle interfaceBicycles, ILogger<UserController> logger)
        {
            this.interfaceBicycles = interfaceBicycles;
            _logger = logger;
        }
        [HttpGet]
        public List<bicycle> getAllBicycles()
        {
            return this.interfaceBicycles.getAllBicycles();
        }

        [HttpGet("{id}")]

        public bicycle getABicycleDetail(int id)
        {
            return this.interfaceBicycles.GetSpecificBicycleDetail(id);
        }

        [HttpPost]

        public bicycle addBicycle(bicycle bicycle)
        {
            return this.interfaceBicycles.addBicycle(bicycle);
        }

        //[HttpPost]

        //public string addBicycle(bicycle bicycle)
        //{
        //    return this.interfaceBicycles.addBicycleDetail(bicycle);
        //}

        [HttpDelete]
        public int deleteBicycle(int id)
        {
            return this.interfaceBicycles.deleteABicycle(id);
        }

        [HttpPut]
        public bicycle updateBicycle(bicycle bicycle)
        {
            return this.interfaceBicycles.updateBicycle(bicycle);
        }
        
    }
}
