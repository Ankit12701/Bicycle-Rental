﻿using BiCycleRental.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using BiCycleRental.Models;
namespace BiCycleRental.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly InterfaceLogin interfaceLogin;
        private readonly ILogger<LoginController> _logger;
        public LoginController(InterfaceLogin interfaceLogin, ILogger<LoginController> logger)
        {
            this.interfaceLogin = interfaceLogin;
            _logger = logger;
        }
        [HttpPost]
        public ActionResult ValidateLogin(login login)
        {
           return this.interfaceLogin.AuthenticateLogin(login);
        }
        [HttpPost("/adminLogin")]
        public ActionResult AdminLogin(login login)
        {
            return this.interfaceLogin.AdminLogin(login);
        }
        //[HttpPost]
        //public ActionResult GetUserDetails(login login)
        //{
        //    return this.interfaceLogin.GetUserDetails(login);
        //}
    }
}
