﻿namespace BiCycleRental.Repository
{
    public class connection
    {
    }
}
