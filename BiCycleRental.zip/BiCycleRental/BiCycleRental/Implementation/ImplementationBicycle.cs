﻿using BiCycleRental.Interface;
using BiCycleRental.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;

namespace BiCycleRental.Implementation
{
    public class ImplementationBicycle : InterfaceBicycle
    {
        public List<bicycle> getAllBicycles()
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48894\\SQLEXPRESS;Database=BiCycle;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();

                string query = "select * from Bicycle";

                SqlCommand cmd = new SqlCommand(query, connection);

                var a = cmd.ExecuteReader();

                if (a.HasRows)
                {
                    List<bicycle> bicycles = new List<bicycle>();



                    while (a.Read())
                    {
                        bicycle bicycle = new bicycle();
                        bicycle.id = Convert.ToInt32(a["id"]);
                        bicycle.brandName = a["brandName"].ToString();
                        bicycle.brandId = Convert.ToInt32(a["brandId"]);
                        bicycle.description = a["description"].ToString();
                        bicycle.pricePerDay = Convert.ToInt32(a["pricePerDay"]);
                        bicycle.imageUrl = a["imageUrl"].ToString();
                        bicycle.color = a["color"].ToString();
                        bicycle.quantity = Convert.ToInt32(a["quantity"]);
                        bicycles.Add(bicycle);
                    }

                    return bicycles;


                }
                else
                {
                    return null;
                }

            }
            catch (Exception)
            {

                throw;
            }

        }
        [HttpPut]
        public bicycle updateBicycle(bicycle bicycle)
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48894\\SQLEXPRESS;Database=BiCycle;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();

                string query = $"update Bicycle set  color='{bicycle.color}', description='{bicycle.description}', imageUrl='{bicycle.imageUrl}', quantity={bicycle.quantity}, pricePerDay={bicycle.pricePerDay} where id={bicycle.id};";

                SqlCommand cmd = new SqlCommand(query, connection);

                // var a = cmd.ExecuteReader();

                //if (cmd.ExecuteNonQuery() == 1)
                //{
                //    return bicycle;
                //}

                var a = cmd.ExecuteReader();
                if (a.HasRows && a.Read())
                    return bicycle;


            }
            catch (Exception)
            {

                throw;
            }
            return null;
        }

        public bicycle GetSpecificBicycleDetail(int id)
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48894\\SQLEXPRESS;Database=BiCycle;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();

                string query = $"select * from Bicycle where id={id};";

                SqlCommand cmd = new SqlCommand(query, connection);

                var a = cmd.ExecuteReader();

                if (a.HasRows && a.Read())
                {
                    bicycle bicycle = new bicycle();
                    bicycle.id = Convert.ToInt32(a["id"]);
                    bicycle.brandName = a["brandName"].ToString();
                    bicycle.brandId = Convert.ToInt32(a["brandId"]);
                    bicycle.description = a["description"].ToString();
                    bicycle.pricePerDay = Convert.ToInt32(a["pricePerDay"]);
                    bicycle.imageUrl = a["imageUrl"].ToString();
                    bicycle.color = a["color"].ToString();
                    bicycle.quantity = Convert.ToInt32(a["quantity"]);

                    return bicycle;

                }
                else
                {
                    return null;
                }

            }
            catch (Exception)
            {

                throw;
            }

        }
        public int deleteABicycle(int id)
        {
            SqlConnection connection = new SqlConnection("Server=APINP-ELPT48894\\SQLEXPRESS;Database=BiCycle;Integrated Security=false;User Id=sa;Password=guvi;");

            connection.Open();

            string query = $"delete  from Bicycle where id={id};";

            SqlCommand cmd = new SqlCommand(query, connection);

            var a = cmd.ExecuteReader();

            if (a.HasRows )
            {
                return 1;

            }
            else
            {
                return 0;
            }
         

        }

        [HttpPost]
        public bicycle addBicycle(bicycle bicycle)
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48894\\SQLEXPRESS;Database=BiCycle;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();
                string query = "insert into Bicycle(brandName,brandId,description, imageUrl, pricePerDay,color,quantity)" +
                             "values( @brandName,@brandId,@description,@imageUrl,@pricePerDay,@color,@quantity);";

                SqlCommand cmd = new SqlCommand(query, connection);

               
                cmd.Parameters.AddWithValue("@brandName", bicycle.brandName);
                cmd.Parameters.AddWithValue("@brandId", bicycle.brandId);
                cmd.Parameters.AddWithValue("@description", bicycle.description);
                cmd.Parameters.AddWithValue("@imageUrl", bicycle.imageUrl);
                cmd.Parameters.AddWithValue("@pricePerDay", bicycle.pricePerDay);
                cmd.Parameters.AddWithValue("@color", bicycle.color);
                cmd.Parameters.AddWithValue("@quantity", bicycle.quantity);

                if (cmd.ExecuteNonQuery() == 1)
                {
                    return bicycle;
                }


            }
            catch (Exception)
            {

                throw;
            }
            return null;
        }


    }
    //[HttpPost]
    //[ProducesResponseType(StatusCodes.Status200OK)]
    //[ProducesResponseType(StatusCodes.Status404NotFound)]
    //public IActionResult addBicycleDetail(bicycle bicycle)
    //{
    //    try
    //    {
    //        SqlConnection connection = new SqlConnection("Server=APINP-ELPT48894\\SQLEXPRESS;Database=BiCycle;Integrated Security=false;User Id=sa;Password=guvi;");

    //        connection.Open();
    //        string query="insert into Bicycle(brandId, brandName, color, description, imageUrl, quantity, pricePerDay)" +
    //                     "values(@brandId, @color,@description,@imageUrl,@quantity,@pricePerDay);";

    //        SqlCommand cmd = new SqlCommand(query, connection);

    //        cmd.Parameters.AddWithValue("@brandId", bicycle.brandId);
    //        cmd.Parameters.AddWithValue("@color", bicycle.color);
    //        cmd.Parameters.AddWithValue("@description", bicycle.description);
    //        cmd.Parameters.AddWithValue("@imageUrl", bicycle.imageUrl);
    //        cmd.Parameters.AddWithValue("@quantity", bicycle.quantity);
    //        cmd.Parameters.AddWithValue("@brandId", bicycle.brandId);
    //        cmd.Parameters.AddWithValue("@pricePerDay", bicycle.pricePerDay);
    //        var a = cmd.ExecuteReader();
    //        if (cmd.ExecuteNonQuery() == 1)
    //        {
    //            return  Ok("success");
    //        }


    //    }
    //    catch (Exception)
    //    {

    //        throw;
    //    }

    //    return "failed";
    //}
}

