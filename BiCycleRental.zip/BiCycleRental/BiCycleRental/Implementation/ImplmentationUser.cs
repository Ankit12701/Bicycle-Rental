﻿using BiCycleRental.Interface;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Data.SqlClient;
using System;
using Microsoft.Extensions.Configuration;
using System.Data;
using BiCycleRental.Models;
namespace BiCycleRental.Implementation
{
    public class ImplmentationUser : InterfaceUser
    {


        public List<user> GetAllUsers()
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48894\\SQLEXPRESS;Database=BiCycle;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();

                string query = "select * from users where role='user'";

                SqlCommand cmd = new SqlCommand(query, connection);

                var a = cmd.ExecuteReader();

                if (a.HasRows)
                {
                    List<user> users = new List<user>();



                    while (a.Read())
                    {
                        user user = new user();
                        user.id = Convert.ToInt32(a["id"]);
                        user.name = a["name"].ToString();
                        user.email = a["email"].ToString();
                        user.age = Convert.ToInt32(a["age"]);
                        user.phonenumber = a["phonenumber"].ToString();
                        user.role = a["role"].ToString();

                        users.Add(user);
                    }

                    return users;


                }
                else
                {
                    return null;
                }

            }
            catch (Exception)
            {

                throw;
            }
        }

        //[HttpGet("{name,password}")]
        public user getAuser(string name, string password)
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48894\\SQLEXPRESS;Database=BiCycle;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();
                // '" + input.name + @"'
                string query = $"select * from users where name = '{name}' and password = '{password}' ;";

                SqlCommand cmd = new SqlCommand(query, connection);

                var a = cmd.ExecuteReader();

                if (a.HasRows && a.Read())
                {
                    user user = new user();
                    user.id = Convert.ToInt32(a["id"]);
                    user.name = a["name"].ToString();
                    user.email = a["email"].ToString();
                    user.age = Convert.ToInt32(a["age"]);
                    user.phonenumber = a["phonenumber"].ToString();
                    user.role = a["role"].ToString();
                    return user;
                }
                else
                {
                    return null;
                }


            }
            catch (Exception)
            {

                throw;
            }
        }

    }

    //public IActionResult postAll(Student stud)
    //{
    //    try
    //    {




    //        SqlConnection connection = new SqlConnection("Server=APINP-ELPT48905\\SQLEXPRESS01;Database=studdetails;Integrated Security=false;User Id=sa;Password=guvi;");
    //        //SqlConnection connection = new SqlConnection(connectionString);



    //        connection.Open();



    //        string query = "INSERT INTO [dbo].[studentDetails]([name],[password])VALUES(@name,@dept)";







    //        SqlCommand cmd = new SqlCommand(query, connection);
    //        cmd.Parameters.AddWithValue("@name", stud.Name);
    //        cmd.Parameters.AddWithValue("@dept", stud.Password);
    //        //  var a = cmd.ExecuteReader();
    //        if (cmd.ExecuteNonQuery() == 1)
    //        {
    //            return Ok("student added");
    //        }
    //    }
    //    catch (Exception)
    //    {



    //        throw;
    //    }





    //    return UnprocessableEntity();
    //}

    
}
