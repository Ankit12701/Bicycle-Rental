﻿using BiCycleRental.Interface;
using BiCycleRental.Models;
using System.Data.SqlClient;
using System.Xml.Linq;
using System;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace BiCycleRental.Implementation
{
    public class ImplementationLogin : ControllerBase, InterfaceLogin
    {
        public ActionResult AuthenticateLogin(login login)
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48894\\SQLEXPRESS;Database=BiCycle;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();
                // '" + input.name + @"'
                string query = "select * from users where name = '" + login.name + @"' and password = '" + login.password + @"'";

                SqlCommand cmd = new SqlCommand(query, connection);

                var a = cmd.ExecuteReader();

                if (a.HasRows)
                {
                    return Ok(200);
                }
                else
                {
                    return NotFound(404);
                }


            }
            catch (Exception)
            {

                throw;
            }
        }
        public ActionResult AdminLogin(login login)
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48894\\SQLEXPRESS;Database=BiCycle;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();
                // '" + input.name + @"'
                string query = "select * from users where name = '" + login.name + @"' and password = '" + login.password + @"' and role='admin'";

                SqlCommand cmd = new SqlCommand(query, connection);

                var a = cmd.ExecuteReader();

                if (a.HasRows)
                {
                    return Ok(200);
                }
                else
                {
                    return NotFound(404);
                }


            }
            catch (Exception)
            {

                throw;
            }
        }
        //public ActionResult GetUserDetails(login login)
        //{
        //    try
        //    {
        //        SqlConnection connection = new SqlConnection("Server=APINP-ELPT48894\\SQLEXPRESS;Database=BiCycle;Integrated Security=false;User Id=sa;Password=guvi;");

        //        connection.Open();
        //        // '" + input.name + @"'
        //        string query = "select * from users where name = '" + login.name + @"' and password = '" + login.password + @"' and role=user";

        //        SqlCommand cmd = new SqlCommand(query, connection);


        //        var a = cmd.ExecuteReader();
        //        user user = new user();
        //        //if (a.hasrows)
        //        //{

        //        if (a.Read())
        //            {

        //                user.id = Convert.ToInt32(a["id"]);
        //                user.name = a["name"].ToString();
        //                user.email = a["email"].ToString();
        //                user.age = Convert.ToInt32(a["age"]);
        //                user.phonenumber = a["phonenumber"].ToString();
        //                user.role = a["role"].ToString();

        //                return Ok(user);
        //             }
        //           else
        //           {
        //            return null;
        //           }



        //        //}


        //    }
        //    catch (Exception)
        //    {

        //        throw;
        //    }
        //}
    }
}
