﻿using BiCycleRental.Interface;
using BiCycleRental.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;

namespace BiCycleRental.Implementation
{
    public class ImplementationBooking : ControllerBase, InterfaceBooking
    {
        public booking addBookingDetails(booking booking)
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48894\\SQLEXPRESS;Database=BiCycle;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();

                string query = "insert into booking (userName,userId,email,bookingDateFrom,bookingDateTo,amount,returnStatus,governmentId,quantity,cycleId)" +
                    "values (@userName,@userId,@email,@bookingDateFrom,@bookingDateTo,@amount,@returnStatus,@governmentId,@quantity,@cycleId)";

                SqlCommand cmd = new SqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@userName", booking.userName);
                cmd.Parameters.AddWithValue("@userId", booking.userId);
                cmd.Parameters.AddWithValue("@email", booking.email);
                cmd.Parameters.AddWithValue("@bookingDateFrom", booking.bookingDateFrom);
                cmd.Parameters.AddWithValue("@bookingDateTo", booking.bookingDateTo);
                cmd.Parameters.AddWithValue("@amount", booking.amount);
                cmd.Parameters.AddWithValue("@returnStatus", booking.returnStatus);
                cmd.Parameters.AddWithValue("@governmentId", booking.governmentId);
                cmd.Parameters.AddWithValue("@quantity", booking.quantity);
                cmd.Parameters.AddWithValue("@cycleId", booking.cycleId);

                if (cmd.ExecuteNonQuery() == 1)
                {
                    return booking;
                }

            }
            catch (Exception)
            {

                throw;
            }
            return null;
        }



        public List<booking> getAllBooking()
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48894\\SQLEXPRESS;Database=BiCycle;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();

                string query = "select * from booking";

                SqlCommand cmd = new SqlCommand(query, connection);

                var a = cmd.ExecuteReader();

                if (a.HasRows)
                {
                    List<booking> bookings = new List<booking>();



                    while (a.Read())
                    {
                        booking booking = new booking();
                        booking.bookingId = Convert.ToInt32(a["bookingId"]);
                        booking.userName = a["userName"].ToString();
                        booking.userId = Convert.ToInt32(a["userId"]);
                        booking.email = a["email"].ToString();
                        booking.bookingDateFrom = a["bookingDateFrom"].ToString();
                        booking.bookingDateTo = a["bookingDateTo"].ToString();
                        booking.amount = Convert.ToInt32(a["amount"]);
                        booking.returnStatus = Convert.ToInt32(a["returnStatus"]);
                        booking.governmentId = a["governmentId"].ToString();
                        booking.quantity = Convert.ToInt32(a["quantity"]);



                        bookings.Add(booking);
                    }

                    return bookings;


                }
                else
                {
                    return null;
                }

            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<booking> getSpecificDateRangeBookings(int cycleId)
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48894\\SQLEXPRESS;Database=BiCycle;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();

                string query = $"select * from booking where cycleId={cycleId}";

                SqlCommand cmd = new SqlCommand(query, connection);

                var a = cmd.ExecuteReader();

                if (a.HasRows)
                {
                    List<booking> bookings = new List<booking>();



                    while (a.Read())
                    {
                        booking booking = new booking();
                        booking.bookingId = Convert.ToInt32(a["bookingId"]);
                        booking.userName = a["userName"].ToString();
                        booking.userId = Convert.ToInt32(a["userId"]);
                        booking.email = a["email"].ToString();
                        booking.bookingDateFrom = a["bookingDateFrom"].ToString();
                        booking.bookingDateTo = a["bookingDateTo"].ToString();
                        booking.amount = Convert.ToInt32(a["amount"]);
                        booking.returnStatus = Convert.ToInt32(a["returnStatus"]);
                        booking.governmentId = a["governmentId"].ToString();
                        booking.quantity = Convert.ToInt32(a["quantity"]);
                        booking.cycleId = Convert.ToInt32(a["cycleId"]);


                        bookings.Add(booking);
                    }

                    return bookings;


                }
                else
                {
                    return null;
                }

            }
            catch (Exception)
            {

                throw;
            }
        }

   

        public List<booking> getBookingByUserId(int userId)
        {
           
                try
                {
                    SqlConnection connection = new SqlConnection("Server=APINP-ELPT48894\\SQLEXPRESS;Database=BiCycle;Integrated Security=false;User Id=sa;Password=guvi;");

                    connection.Open();

                    string query = $"select * from booking where userId={userId}";

                    SqlCommand cmd = new SqlCommand(query, connection);

                    var a = cmd.ExecuteReader();

                    if (a.HasRows)
                    {
                        List<booking> bookings = new List<booking>();



                        while (a.Read())
                        {
                            booking booking = new booking();
                            booking.bookingId = Convert.ToInt32(a["bookingId"]);
                            booking.userName = a["userName"].ToString();
                            booking.userId = Convert.ToInt32(a["userId"]);
                            booking.email = a["email"].ToString();
                            booking.bookingDateFrom = a["bookingDateFrom"].ToString();
                            booking.bookingDateTo = a["bookingDateTo"].ToString();
                            booking.amount = Convert.ToInt32(a["amount"]);
                            booking.returnStatus = Convert.ToInt32(a["returnStatus"]);
                            booking.governmentId = a["governmentId"].ToString();
                            booking.quantity = Convert.ToInt32(a["quantity"]);



                            bookings.Add(booking);
                        }

                        return bookings;


                    }
                    
                }
                catch (Exception)
                {

                    throw;
                }
            return null;
            }
    }
    }


