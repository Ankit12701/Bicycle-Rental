﻿using BiCycleRental.Interface;
using BiCycleRental.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace BiCycleRental.Implementation
{
    public class ImplementationTransaction : InterfaceTransaction
    {
        public transaction addTransaction(transaction transaction)
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48894\\SQLEXPRESS;Database=BiCycle;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();

                string query = "insert into Booking_transaction (transactionId,userName,userId,bookingDateFrom,bookingDateTo,amount)" +
                    "values (@transactionId,@userName,@userId,@bookingDateFrom,@bookingDateTo,@amount)";

                SqlCommand cmd = new SqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@transactionId", transaction.transactionId);
                cmd.Parameters.AddWithValue("@userName", transaction.userName);
                cmd.Parameters.AddWithValue("@userId", transaction.userId);
               
                cmd.Parameters.AddWithValue("@bookingDateFrom", transaction.bookingDateTo);
                cmd.Parameters.AddWithValue("@bookingDateTo", transaction.bookingDateTo);
                cmd.Parameters.AddWithValue("@amount", transaction.amount);


                if (cmd.ExecuteNonQuery() == 1)
                {
                    return transaction;
                }

            }
            catch (Exception)
            {

                throw;
            }
            return null;
        }

        public List<transaction> getAllTransaction()
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48894\\SQLEXPRESS;Database=BiCycle;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();

                string query = "select * from Booking_transaction";

                SqlCommand cmd = new SqlCommand(query, connection);

                var a = cmd.ExecuteReader();

                if (a.HasRows)
                {
                    List<transaction> transactions = new List<transaction>();



                    while (a.Read())
                    {
                        transaction transaction = new transaction();
                        transaction.transactionId = Convert.ToInt32(a["transactionId"]);
                        transaction.userName = a["userName"].ToString();
                        transaction.userId= Convert.ToInt32(a["userId"]);
                     
                        transaction.bookingDateFrom = a["bookingDateFrom"].ToString();
                        transaction.bookingDateTo = a["bookingDateTo"].ToString();
                        transaction.amount = Convert.ToInt32(a["amount"]);

                        transactions.Add(transaction);
                    }

                    return transactions;


                }
                else
                {
                    return null;
                }

            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<transaction> getAllTransactionByUserId(int userId)
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48894\\SQLEXPRESS;Database=BiCycle;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();

                string query = $"select * from Booking_transaction where userId={userId}";

                SqlCommand cmd = new SqlCommand(query, connection);

                var a = cmd.ExecuteReader();

                if (a.HasRows)
                {
                    List<transaction> transactions = new List<transaction>();



                    while (a.Read())
                    {
                        transaction transaction = new transaction();
                        transaction.transactionId = Convert.ToInt32(a["transactionId"]);
                        transaction.userName = a["userName"].ToString();
                        transaction.userId = Convert.ToInt32(a["userId"]);

                        transaction.bookingDateFrom = a["bookingDateFrom"].ToString();
                        transaction.bookingDateTo = a["bookingDateTo"].ToString();
                        transaction.amount = Convert.ToInt32(a["amount"]);

                        transactions.Add(transaction);
                    }

                    return transactions;


                }
                else
                {
                    return null;
                }

            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
