﻿namespace BiCycleRental.Interface
{
    public class Ibooking
    {
    }
}
