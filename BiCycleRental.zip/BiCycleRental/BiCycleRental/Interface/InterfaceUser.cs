﻿using System.Collections.Generic;
using BiCycleRental.Models;
namespace BiCycleRental.Interface
{
    public interface InterfaceUser
    {


        public List<user> GetAllUsers();
        public user getAuser(string name, string password);

    }
}
