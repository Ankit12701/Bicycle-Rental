﻿using BiCycleRental.Models;
using Microsoft.AspNetCore.Mvc;

namespace BiCycleRental.Interface
{
    public interface InterfaceLogin
    {
        public ActionResult AuthenticateLogin(login login);

        //public ActionResult GetUserDetails(login login);

        public ActionResult AdminLogin(login login);
    }
}
