﻿using BiCycleRental.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace BiCycleRental.Interface
{
    public interface InterfaceBicycle
    {
        public List<bicycle> getAllBicycles();

        public bicycle GetSpecificBicycleDetail(int id);

        //public ActionResult addBicycleDetail(bicycle bicycle);

        public int deleteABicycle(int id);


        public bicycle addBicycle(bicycle bicycle);

        public bicycle updateBicycle(bicycle bicycle);        
       
    }
}
