﻿using BiCycleRental.Models;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace BiCycleRental.Interface
{
    public interface InterfaceBooking
    {
        public List<booking> getAllBooking();

        public List<booking> getSpecificDateRangeBookings(int cycleId);

        public booking addBookingDetails(booking booking);

      
        public List<booking> getBookingByUserId(int userId);
    }
}
