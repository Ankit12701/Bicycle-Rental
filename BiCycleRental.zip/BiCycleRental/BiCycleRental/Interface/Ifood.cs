﻿namespace BiCycleRental.Interface
{
    public class Ifood
    {
        public string name { get; set; }
        public int id { get; set; }
        public string loction { get; set; }

    }
}
