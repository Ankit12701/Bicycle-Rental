﻿using System.Collections.Generic;
using BiCycleRental.Models;
namespace BiCycleRental.Interface
{
    public interface InterfaceTransaction
    {
        public List<transaction> getAllTransaction();

        public transaction addTransaction(transaction transaction);

        public List<transaction> getAllTransactionByUserId(int userId);

    }
}
