﻿namespace BiCycleRental.Models
{
    public class bicycle
    {
        public int id { get; set; }
        public string brandName { get; set; }
        public int brandId { get; set; }
        public string description { get; set; }
        public string imageUrl { get; set; }
        public int pricePerDay { get; set; }

        public string color { get; set; }

        public int quantity { get; set; }
    }
}
