﻿namespace BiCycleRental.Models
{
    public class booking
    {
        public int bookingId { get; set; }
        public string userName { get; set; }

        public int userId { get; set; }
        public string email { get; set; }
        public string bookingDateFrom { get; set; }
        public string bookingDateTo { get; set; }
        public int amount { get; set; }
        public int returnStatus { get; set; }
        public string governmentId { get; set; }
        public int quantity { get; set; }

        public int cycleId { get; set; }


    }
}
