﻿namespace BiCycleRental.Models
{
    public class user
    {
        public string name { get; set; }
        public int age { get; set; }
        public string email { get; set; }
        public int id { get; set; }

        public string password { get; set; }

        public string role { get; set; }

        public string phonenumber { get; set; }


    }
}
