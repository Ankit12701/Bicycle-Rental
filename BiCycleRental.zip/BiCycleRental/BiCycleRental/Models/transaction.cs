﻿namespace BiCycleRental.Models
{
    public class transaction
    {
        public int transactionId { get; set; }
        public string userName { get; set; }

        public int userId { get; set; }

       
        public string bookingDateFrom { get; set; }

        public string bookingDateTo { get; set; }

        public int amount { get; set; }
    }
}
