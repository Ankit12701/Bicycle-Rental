﻿namespace BiCycleRental.Models
{
    public class login
    {
        public string name { get; set; }
        public string password { get; set; }
    }
}
